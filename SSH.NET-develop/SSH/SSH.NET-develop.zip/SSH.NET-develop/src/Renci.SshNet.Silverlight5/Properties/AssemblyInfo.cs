﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("SSH.NET Silverlight 5")]
[assembly: Guid("2b3f6251-8079-48aa-a76b-df70e40092e2")]