﻿using Renci.SshNet.Messages.Transport;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace Renci.SshNet.Tests.Classes.Messages.Transport
{
    /// <summary>
    ///This is a test class for ServiceAcceptMessageTest and is intended
    ///to contain all ServiceAcceptMessageTest Unit Tests
    ///</summary>
    [TestClass]
    public class ServiceAcceptMessageTest
    {
        /// <summary>
        ///A test for ServiceAcceptMessage Constructor
        ///</summary>
        [TestMethod]
        [Ignore] // placeholder
        public void ServiceAcceptMessageConstructorTest()
        {
            ServiceAcceptMessage target = new ServiceAcceptMessage();
            Assert.Inconclusive("TODO: Implement code to verify target");
        }
    }
}
