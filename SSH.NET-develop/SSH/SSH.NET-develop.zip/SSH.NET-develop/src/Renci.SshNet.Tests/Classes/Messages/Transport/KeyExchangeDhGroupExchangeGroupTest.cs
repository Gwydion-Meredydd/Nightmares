﻿using Renci.SshNet.Messages.Transport;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Renci.SshNet.Tests.Common;

namespace Renci.SshNet.Tests.Classes.Messages.Transport
{
    /// <summary>
    ///This is a test class for KeyExchangeDhGroupExchangeGroupTest and is intended
    ///to contain all KeyExchangeDhGroupExchangeGroupTest Unit Tests
    ///</summary>
    [TestClass]
    public class KeyExchangeDhGroupExchangeGroupTest : TestBase
    {
        /// <summary>
        ///A test for KeyExchangeDhGroupExchangeGroup Constructor
        ///</summary>
        [TestMethod]
        [Ignore] // placeholder
        public void KeyExchangeDhGroupExchangeGroupConstructorTest()
        {
            KeyExchangeDhGroupExchangeGroup target = new KeyExchangeDhGroupExchangeGroup();
            Assert.Inconclusive("TODO: Implement code to verify target");
        }
    }
}
