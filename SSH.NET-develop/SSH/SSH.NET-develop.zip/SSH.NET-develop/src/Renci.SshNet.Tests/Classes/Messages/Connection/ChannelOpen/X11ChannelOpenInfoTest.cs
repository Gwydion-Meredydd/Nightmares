﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Renci.SshNet.Tests.Common;

namespace Renci.SshNet.Tests.Classes.Messages.Connection
{
    /// <summary>
    /// Used to open "x11" channel type
    /// </summary>
    [TestClass]
    public class X11ChannelOpenInfoTest : TestBase
    {
    }
}