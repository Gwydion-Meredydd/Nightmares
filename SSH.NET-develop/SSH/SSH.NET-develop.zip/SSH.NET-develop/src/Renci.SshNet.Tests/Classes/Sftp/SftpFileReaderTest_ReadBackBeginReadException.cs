﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Renci.SshNet.Tests.Classes.Sftp
{
    class SftpFileReaderTest_ReadBackBeginReadException
    {
    }
}
